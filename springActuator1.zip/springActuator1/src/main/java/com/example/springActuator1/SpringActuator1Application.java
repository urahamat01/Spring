package com.example.springActuator1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringActuator1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringActuator1Application.class, args);
	}

}
